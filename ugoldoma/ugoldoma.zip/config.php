<?php 
	return
	[
		'host' => 'localhost',
		'db_name' => 'Karush',
		'username' => 'root',
		'password' => '',
		'charset' => 'utf8'
	];
 ?>