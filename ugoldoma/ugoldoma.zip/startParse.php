<?php
include_once('parser_configs.php');
include_once('simple_html_dom.php');
include_once('Phantom.php');
// require_once('database.php');
// $db = new Database;

// translate function
function translit($str) {
	$rus = array('А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я', 'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я','№',' ');
	$lat = array('A', 'B', 'V', 'G', 'D', 'E', 'E', 'Gh', 'Z', 'I', 'Y', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'F', 'H', 'C', 'Ch', 'Sh', 'Sch', 'Y', 'Y', 'Y', 'E', 'Yu', 'Ya', 'a', 'b', 'v', 'g', 'd', 'e', 'e', 'gh', 'z', 'i', 'y', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'h', 'c', 'ch', 'sh', 'sch', 'y', 'y', 'y', 'e', 'yu', 'ya', 'No','_');
	return str_replace($rus, $lat, $str);
}

$catalogUrl = 'https://xn--80asecmsgbp.xn--p1ai/dekorativnyj-kirpich/';
$html = file_get_html($catalogUrl);
$productContainer = $html->find('.row')[6];
$productItems = $productContainer->find('.product-layout');
$productCount = 1;
var_dump('aaaaaaaaaaaaaa');die;
foreach ($productItems as $items) {
	$singlePage = $items->find('a')[0];
	$singlePageUrl = $singlePage->href;
	$fullProductPageUrl = $singlePageUrl;
	$productSinglePage = file_get_html($fullProductPageUrl);
	$productName = $productSinglePage->find('h1')[0]->text();
	var_dump($productName);die;
	// $getProductSkuBlock = $productSinglePage->find('.sku-field')[0]->text();
	// $productSkuSplit = explode(" ",$getProductSkuBlock);
	// $productSku = $productSkuSplit[1];
	$productPriceBlock = $productSinglePage->find('#formated_price')[0]->text();
	$prodPriceReplace = str_replace("руб", "", $productPriceBlock);
	$productPrice = str_replace('.', "", $prodPriceReplace);
	$productPrice = str_replace(' ', "", $productPrice);
	$productSpecificationTab = $productSinglePage->find('#tab-specification');
	$tbodys = $productSpecificationTab[0]->find('tbody');
	// tbodu foreach
	$prod_length = 0;
	$prod_width = 0;
	$prod_heigth = 0;

	$spec = [];
	foreach ($tbodys as $tbody) {
		$trs = $tbody->find('tr');
		foreach ($trs as $tr) {
			$tds = $tr->find('td');
			$name = trim($tds[0]->text());
			$value = trim($tds[1]->text());
			if ($name == 'Размер упаковки (ДхШхВ)') {
				$splited = explode('х', $value);
				var_dump($splited);die;
			}
			// echo $tds[0]->text(). ' - ';
			// echo $tds[1]->text().'<br>';
			// $attrSpec = [
			// 	'name' => trim($tds[0]->text()),
			// 	'value' => trim($tds[1]->text()),
			// ];
			// array_push($spec, $attrSpec);
		}
	}

	$translateName = translit($productName);
	$lowerCaseProductName = strtolower($translateName);
	// create directory for product images
	$directoryName = 'catalog/products/'.$lowerCaseProductName.'_'.$count++;

	//Check if the directory already exists.
	if(!is_dir($directoryName)){
		mkdir($directoryName, 0755);
	}

	$imgCount = 0;
	$imgBlock = $productSinglePage->find('#one-image');
	$imgTag = $imgBlock[0]->find('img');
	$mainImage = '';
	foreach ($imgTag as $imgSrc) {
		$imageSrc = $imgSrc->src;
		$imageName = $lowerCaseProductName.'_'.$imgCount;
		$output = $directoryName.'/'.$imageName.'.jpg';
		file_put_contents($output, file_get_contents($imageSrc));
		if ($imgCount == 0) {
			$mainImage = $imageName;
		}
		$imgCount++;
	}

	$descriptionTab =  $productSinglePage->find('#tab-description');
	$desc = '';
	if (!empty($descriptionTab[0]->text())) {
		$desc = $descriptionTab[0]->text();
	}

	$prodSku = '0000'.$productCount;
	$prodPrice = $productPrice;
	$prodMainImage = $mainImage;

	$GLOBALS['db']->execute("INSERT IGNORE INTO `oc_product` SET `product_id` = '$productCount', `model` = '$prodSku', `sku` = '$prodSku', `upc` = '$prodSku', `ean` = '$prodSku', `jan` = '$prodSku', `isbn` = '$prodSku', `mpn` = '$prodSku', `quantity` = 100, `price` = '$prodPrice', `stock_status_id` = 7, `image` = '$prodMainImage', `manufacturer_id` = 4, `status` = 1, `shipping` = 1, `date_available` = '2020-07-20', `weight_class_id` = 1,  ");
}